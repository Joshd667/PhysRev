// js/features/tags/index.js
// Exports all tag-related methods

export { tagManagementMethods } from './management.js';
